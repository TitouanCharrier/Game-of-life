var searchData=
[
  ['savemap_84',['SaveMap',['../game__of__life__gui_8h.html#a138c710ecc862e5bec03f0dfd3bc2b0c',1,'game_of_life_gui.h']]]
];
