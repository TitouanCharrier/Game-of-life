var searchData=
[
  ['savemap_36',['SaveMap',['../game__of__life__gui_8h.html#a138c710ecc862e5bec03f0dfd3bc2b0c',1,'game_of_life_gui.h']]],
  ['st_5fcolor_37',['St_Color',['../structSt__Color.html',1,'']]],
  ['st_5flist_38',['St_List',['../structSt__List.html',1,'']]],
  ['st_5fstate_39',['St_State',['../structSt__State.html',1,'']]],
  ['st_5fthread_40',['St_Thread',['../structSt__Thread.html',1,'']]],
  ['st_5fvar_41',['St_Var',['../structSt__Var.html',1,'']]],
  ['struct_2eh_42',['struct.h',['../struct_8h.html',1,'']]]
];
