var searchData=
[
  ['game_5fof_5flife_2eh_10',['game_of_life.h',['../game__of__life_8h.html',1,'']]],
  ['game_5fof_5flife_5fgui_2eh_11',['game_of_life_gui.h',['../game__of__life__gui_8h.html',1,'']]],
  ['grid_12',['Grid',['../structGrid.html',1,'']]]
];
