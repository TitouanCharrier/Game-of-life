var searchData=
[
  ['refreshbuttons_82',['RefreshButtons',['../game__of__life__gui_8h.html#a344bb922c8d943bd8d6fe315ddbe873a',1,'game_of_life_gui.h']]],
  ['removecell_83',['RemoveCell',['../game__of__life__gui_8h.html#a7aed99649690406613da92a4e90c3913',1,'game_of_life_gui.h']]]
];
