var searchData=
[
  ['location_48',['location',['../structlocation.html',1,'']]]
];
