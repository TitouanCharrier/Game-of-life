var searchData=
[
  ['findbutton_63',['FindButton',['../game__of__life__gui_8h.html#af4956d49bbc8a4f680a9ffe16c6eb192',1,'game_of_life_gui.h']]]
];
