var searchData=
[
  ['handlekeydown_13',['HandleKeyDown',['../game__of__life__gui_8h.html#a562fa800da03fc6cd940e675b733e6b3',1,'game_of_life_gui.h']]],
  ['handlekeyup_14',['HandleKeyUp',['../game__of__life__gui_8h.html#a3ddccd96b94bfddcb031734788332bda',1,'game_of_life_gui.h']]]
];
