var searchData=
[
  ['button_0',['Button',['../structButton.html',1,'']]],
  ['buttonfunc_1',['ButtonFunc',['../game__of__life__gui_8h.html#af27d1fa588e6fbbe9ace9042108c93a5',1,'game_of_life_gui.h']]]
];
