var searchData=
[
  ['buttonfunc_58',['ButtonFunc',['../game__of__life__gui_8h.html#af27d1fa588e6fbbe9ace9042108c93a5',1,'game_of_life_gui.h']]]
];
